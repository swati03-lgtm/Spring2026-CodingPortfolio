LAB 4 IS 170 

SWATI

Aidan Gonzales

# Dataset: https://www.kaggle.com/datasets/prokshitha/home-value-insights
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt 
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# We selected 5 principal components because they capture most of the
# total variance in the dataset while significantly reducing the
# number of dimensions. This balances information retention with
# model simplicity.

Housing_data =pd.read_csv("house_price_regression_dataset.csv")
print("Dataset shape:", Housing_data.shape)
print(Housing_data.head())

# Select all columns except the target variable 'House_Price'
features = [col for col in Housing_data.columns if col != 'House_Price']

# Print feature names and total number of features
print("\nFeatures ({})".format(len(features)), features)

# Display distribution of house prices (for reference)
print("\nLabel counts:\n", Housing_data['House_Price'].value_counts().sort_index())

# PCA requires standardized data because it is sensitive to scale.
# StandardScaler transforms data so that:
# Mean = 0
# Standard Deviation = 1
x = StandardScaler().fit_transform(Housing_data[features])

# Verify normalization worked correctly
print("\nNormalized data - Mean: {:.4f}, std: {:.4f}".format(x.mean(), x.std()))


# Initialize PCA model with 5 principal components
# We selected 5 components because they capture most of
# the total variance while reducing dimensionality.
pca = PCA(n_components=5)

# Fit PCA model and transform standardized data
principal_components = pca.fit_transform(x)

# Create DataFrame containing principal components
pca_df = pd.DataFrame(principal_components,
                      columns=['PC1', 'PC2', 'PC3', 'PC4', 'PC5'])


# Print variance explained by each principal component
print("\nExplained variance per component:")
print(" PC1: {:.1%}  |  PC2: {:.1%}  |  PC3: {:.1%}  |  PC4: {:.1%}  |  PC5: {:.1%}"
      .format(*pca.explained_variance_ratio_))

# Print total variance captured by all 5 components
print(" Combined: {:.1%} of total variance captured"
      .format(sum(pca.explained_variance_ratio_)))

# Divide House_Price into 3 equal groups (Low, Medium, High)
# qcut splits data into quantiles
Housing_data['Price_Category'] = pd.qcut(
    Housing_data['House_Price'],
    q=3,
    labels=[1, 2, 3]
)

# Create scatter plot of first two principal components
plt.figure(figsize=(10, 10))

plt.xlabel('Principal Component 1', fontsize=12)
plt.ylabel('Principal Component 2', fontsize=12)
plt.title('PCA of Housing Prices', fontsize=15)

plt.xticks(fontsize=10)
plt.yticks(fontsize=10)

# Assign colors and labels to each price category
colors = {
    1: ('r', 'Low Price'),
    2: ('b', 'Medium Price'),
    3: ('g', 'High Price')
}

# Plot each price category separately
for label, (color, name) in colors.items():
    mask = Housing_data['Price_Category'] == label
    plt.scatter(
        pca_df.loc[mask, 'PC1'],
        pca_df.loc[mask, 'PC2'],
        c=color,
        s=50,
        label=name
    )

# Add legend
plt.legend(prop={'size': 10})

# Adjust layout for better spacing
plt.tight_layout()

# Save plot as image file
plt.savefig('pca_housing_prices.png', dpi=150)

# Display plot
plt.show()

print("\nPlot saved as 'pca_housing_prices.png'")


#The purpose of this algorithm is to predict housing prices based on various features using PCA for dimensionality reduction.
#This helps identify house prices into three categories: low, medium, and high, based on the different features of houses.
#How this helps buys and sellers in based on the price there are certain features that must be met based on the data provided by the algorithm.

In order to reduce the dimensionality of the data while maintaining the most crucial information,
Principal Component Analysis (PCA) was used in this lab on a dataset of home prices. Multiple associated home factors,
including square footage, number of beds, and other property attributes, were initially included in the dataset.
Following feature standardization, PCA was used to reduce the dataset to five principle components that accounted for the majority of 
the variance. To look for trends across the low, medium, and high price categories, the first two components were visualized.
In addition to increasing computational efficiency and simplifying complicated housing data, this dimensionality reduction aids
in identifying the major variables affecting housing prices.


